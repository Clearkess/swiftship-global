/**
 * SwiftShip Global — Admin Dashboard Logic
 * Firebase Auth protected
 */

'use strict';

// ── State ──
let _shipments = [], _quotes = [], _contacts = [];
let shipPage = 1, quotePage = 1, msgPage = 1;
const PAGE_SIZE = 10;
let statusChart = null, modeChart = null;
let pendingDeleteFn = null;

// ── Tab switching ──
function switchTab(name) {
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const panel = document.getElementById('tab-' + name);
  if (panel) panel.classList.add('active');
  const navItem = document.querySelector(`.nav-item[data-tab="${name}"]`);
  if (navItem) navItem.classList.add('active');
  document.getElementById('topbarTitle').textContent =
    { dashboard: 'Dashboard', shipments: 'Shipments', quotes: 'Quote Requests',
      messages: 'Messages', tracking: 'Tracking Lookup', settings: 'Settings' }[name] || name;
  if (name === 'dashboard') renderDashboard();
  if (name === 'shipments') renderShipments();
  if (name === 'quotes')    renderQuotes();
  if (name === 'messages')  renderMessages();
}

document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', e => {
    e.preventDefault();
    switchTab(item.dataset.tab);
    // Close sidebar on mobile
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('overlay').classList.remove('show');
  });
});

// ── Mobile sidebar ──
document.getElementById('menuBtn').addEventListener('click', () => {
  document.getElementById('sidebar').classList.add('open');
  document.getElementById('overlay').classList.add('show');
});
document.getElementById('sidebarClose').addEventListener('click', () => {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('overlay').classList.remove('show');
});
document.getElementById('overlay').addEventListener('click', () => {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('overlay').classList.remove('show');
});

// ── User info ──
window.populateUserInfo = function(user) {
  if (!user) return;
  const name    = user.displayName || user.email?.split('@')[0] || 'Admin';
  const initial = name.charAt(0).toUpperCase();
  ['sidebarAvatar','topbarAvatar','settingsAvatar'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = initial;
  });
  setTextById('sidebarName', name);
  setTextById('topbarName', name);
  setTextById('settingsName', name);
  setTextById('sidebarEmail', user.email || '');
  setTextById('settingsEmail', user.email || '');
};

function setTextById(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

// ── Logout ──
async function doLogout() {
  try { await signOut(); } catch(e) {}
  window.location.replace('login.html');
}
document.getElementById('logoutSidebar').addEventListener('click', doLogout);
document.getElementById('logoutTop').addEventListener('click', doLogout);
document.getElementById('logoutSettings').addEventListener('click', doLogout);

// ── Modals ──
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
window.closeModal = closeModal;

// ── Helpers ──
function statusClass(s) {
  if (!s) return '';
  return 'status-' + s.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z-]/g,'');
}

function formatDate(val) {
  if (!val) return '—';
  try {
    const d = val.toDate ? val.toDate() : new Date(val);
    return d.toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' });
  } catch(e) { return val; }
}

// ── Load all data ──
async function loadAllData() {
  const settle = p => p.then(v => v).catch(e => {
    if (e?.code === 'permission-denied') {
      console.warn('[Admin] Firestore permission denied — please set security rules in Firebase Console.');
    } else {
      console.warn('[Admin] Data load warning:', e?.message);
    }
    return [];
  });
  [_shipments, _quotes, _contacts] = await Promise.all([
    settle(getShipments(500)),
    settle(getQuoteRequests(500)),
    settle(getContactMessages(500))
  ]);
  updateUnreadBadge();
}

function updateUnreadBadge() {
  const count = _contacts.filter(c => !c.read).length;
  const badge = document.getElementById('unreadBadge');
  if (badge) {
    badge.textContent = count;
    badge.classList.toggle('show', count > 0);
  }
}

// ═══════════════════════════════════════
// DASHBOARD
// ═══════════════════════════════════════
function renderDashboard() {
  // KPI
  setTextById('kpiTotal', _shipments.length);
  setTextById('kpiTransit', _shipments.filter(s => s.status === 'In Transit').length);
  setTextById('kpiDelivered', _shipments.filter(s => s.status === 'Delivered').length);
  setTextById('kpiQuotes', _quotes.length);

  // Charts
  const statusCounts = {};
  _shipments.forEach(s => { statusCounts[s.status || 'Unknown'] = (statusCounts[s.status || 'Unknown'] || 0) + 1; });
  const modeCounts = {};
  _shipments.forEach(s => { modeCounts[s.mode || 'Unknown'] = (modeCounts[s.mode || 'Unknown'] || 0) + 1; });

  const chartDefaults = { animation: false, responsive: true, maintainAspectRatio: false };

  if (statusChart) statusChart.destroy();
  statusChart = new Chart(document.getElementById('statusChart'), {
    type: 'doughnut',
    data: {
      labels: Object.keys(statusCounts),
      datasets: [{ data: Object.values(statusCounts), backgroundColor: ['#3b82f6','#e8612d','#f59e0b','#a855f7','#22c55e','#ef4444','#64748b'], borderWidth: 0 }]
    },
    options: { ...chartDefaults, plugins: { legend: { position: 'right', labels: { color: '#94a3b8', font: { size: 12 } } } } }
  });

  if (modeChart) modeChart.destroy();
  modeChart = new Chart(document.getElementById('modeChart'), {
    type: 'bar',
    data: {
      labels: Object.keys(modeCounts),
      datasets: [{ label: 'Shipments', data: Object.values(modeCounts), backgroundColor: '#e8612d', borderRadius: 6 }]
    },
    options: { ...chartDefaults, plugins: { legend: { display: false } }, scales: { x: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255,255,255,0.05)' } }, y: { ticks: { color: '#94a3b8', precision: 0 }, grid: { color: 'rgba(255,255,255,0.05)' } } } }
  });

  // Recent table
  const recent = [..._shipments].slice(0, 8);
  const tbody = document.getElementById('recentBody');
  if (recent.length === 0) {
    tbody.innerHTML = '<tr class="empty-row"><td colspan="5">No shipments yet</td></tr>';
  } else {
    tbody.innerHTML = recent.map(s => `
      <tr>
        <td class="td-id">${s.trackingId || '—'}</td>
        <td>${s.sender || '—'}</td>
        <td>${s.destination || '—'}</td>
        <td><span class="status-badge ${statusClass(s.status)}">${s.status || '—'}</span></td>
        <td>${s.eta || '—'}</td>
      </tr>`).join('');
  }
}

// ═══════════════════════════════════════
// SHIPMENTS
// ═══════════════════════════════════════
function getFilteredShipments() {
  const q = document.getElementById('shipSearch').value.toLowerCase();
  const status = document.getElementById('shipStatusFilter').value;
  const mode   = document.getElementById('shipModeFilter').value;
  return _shipments.filter(s =>
    (!q || [s.trackingId, s.sender, s.receiver, s.origin, s.destination].some(v => v?.toLowerCase().includes(q))) &&
    (!status || s.status === status) &&
    (!mode   || s.mode === mode)
  );
}

function renderShipments() {
  const data = getFilteredShipments();
  const start = (shipPage - 1) * PAGE_SIZE;
  const page  = data.slice(start, start + PAGE_SIZE);
  const tbody = document.getElementById('shipBody');
  if (page.length === 0) {
    tbody.innerHTML = '<tr class="empty-row"><td colspan="8">No shipments found</td></tr>';
  } else {
    tbody.innerHTML = page.map(s => `
      <tr>
        <td class="td-id">${s.trackingId || '—'}</td>
        <td>${s.sender || '—'}</td>
        <td>${s.origin || '—'}</td>
        <td>${s.destination || '—'}</td>
        <td>${s.mode || '—'}</td>
        <td><span class="status-badge ${statusClass(s.status)}">${s.status || '—'}</span></td>
        <td>${s.eta || '—'}</td>
        <td>
          <button class="btn-icon edit" onclick="editShipment('${s.id}')" title="Edit"><i class="fas fa-edit"></i></button>
          <button class="btn-icon del" onclick="confirmDelete('shipment','${s.id}')" title="Delete"><i class="fas fa-trash"></i></button>
        </td>
      </tr>`).join('');
  }
  renderPagination('shipPagination', data.length, shipPage, p => { shipPage = p; renderShipments(); });
}

['shipSearch','shipStatusFilter','shipModeFilter'].forEach(id => {
  document.getElementById(id)?.addEventListener('input', () => { shipPage = 1; renderShipments(); });
});
document.getElementById('shipRefresh')?.addEventListener('click', async () => {
  _shipments = await getShipments(500);
  renderShipments();
});

// Add Shipment
document.getElementById('addShipmentBtn')?.addEventListener('click', () => {
  clearShipForm();
  document.getElementById('shipModalTitle').textContent = 'Add Shipment';
  document.getElementById('shipId').value = '';
  openModal('shipModal');
});

function clearShipForm() {
  ['fSender','fReceiver','fOrigin','fDest','fWeight','fEta','fDesc'].forEach(id => {
    const el = document.getElementById(id); if (el) el.value = '';
  });
  document.getElementById('fMode').value = 'Sea Freight';
  document.getElementById('fStatus').value = 'Processing';
}

window.editShipment = function(id) {
  const s = _shipments.find(x => x.id === id);
  if (!s) return;
  document.getElementById('shipId').value = s.id;
  document.getElementById('fSender').value   = s.sender || '';
  document.getElementById('fReceiver').value = s.receiver || '';
  document.getElementById('fOrigin').value   = s.origin || '';
  document.getElementById('fDest').value     = s.destination || '';
  document.getElementById('fMode').value     = s.mode || 'Sea Freight';
  document.getElementById('fStatus').value   = s.status || 'Processing';
  document.getElementById('fWeight').value   = s.weight || '';
  document.getElementById('fEta').value      = s.eta || '';
  document.getElementById('fDesc').value     = s.description || '';
  document.getElementById('shipModalTitle').textContent = 'Edit Shipment';
  openModal('shipModal');
};

document.getElementById('saveShipBtn')?.addEventListener('click', async () => {
  const id = document.getElementById('shipId').value;
  const data = {
    sender:      document.getElementById('fSender').value.trim(),
    receiver:    document.getElementById('fReceiver').value.trim(),
    origin:      document.getElementById('fOrigin').value.trim(),
    destination: document.getElementById('fDest').value.trim(),
    mode:        document.getElementById('fMode').value,
    status:      document.getElementById('fStatus').value,
    weight:      document.getElementById('fWeight').value.trim(),
    eta:         document.getElementById('fEta').value,
    description: document.getElementById('fDesc').value.trim()
  };
  if (!data.sender || !data.origin || !data.destination) {
    alert('Please fill in required fields: Sender, Origin, Destination.');
    return;
  }
  try {
    if (id) {
      await updateShipment(id, data);
      const idx = _shipments.findIndex(s => s.id === id);
      if (idx !== -1) _shipments[idx] = { ..._shipments[idx], ...data };
    } else {
      const created = await createShipment(data);
      _shipments.unshift(created);
    }
    closeModal('shipModal');
    renderShipments();
    renderDashboard();
  } catch(err) { alert('Error saving shipment: ' + err.message); }
});

// ═══════════════════════════════════════
// QUOTES
// ═══════════════════════════════════════
function getFilteredQuotes() {
  const q = document.getElementById('quoteSearch').value.toLowerCase();
  const status = document.getElementById('quoteStatusFilter').value;
  return _quotes.filter(x =>
    (!q || [x.name, x.email, x.company, x.origin, x.destination].some(v => v?.toLowerCase().includes(q))) &&
    (!status || x.status === status)
  );
}

function renderQuotes() {
  const data = getFilteredQuotes();
  const start = (quotePage - 1) * PAGE_SIZE;
  const page  = data.slice(start, start + PAGE_SIZE);
  const tbody = document.getElementById('quoteBody');
  if (page.length === 0) {
    tbody.innerHTML = '<tr class="empty-row"><td colspan="8">No quote requests found</td></tr>';
  } else {
    tbody.innerHTML = page.map(q => `
      <tr>
        <td>${formatDate(q.createdAt)}</td>
        <td>${q.name || '—'}</td>
        <td>${q.company || '—'}</td>
        <td>${(q.origin || '—') + ' → ' + (q.destination || '—')}</td>
        <td>${q.mode || '—'}</td>
        <td>${q.weight ? q.weight + ' kg' : '—'}</td>
        <td>
          <select class="quote-status-sel" data-id="${q.id}" onchange="changeQuoteStatus(this)" style="font-size:12px;padding:4px 8px;background:#1e293b;color:#e2e8f0;border:1px solid rgba(255,255,255,0.1);border-radius:6px">
            <option value="new" ${q.status==='new'?'selected':''}>New</option>
            <option value="reviewed" ${q.status==='reviewed'?'selected':''}>Reviewed</option>
            <option value="converted" ${q.status==='converted'?'selected':''}>Converted</option>
          </select>
        </td>
        <td>
          <button class="btn-icon" onclick="viewQuote('${q.id}')" title="View"><i class="fas fa-eye"></i></button>
          <button class="btn-icon del" onclick="confirmDelete('quote','${q.id}')" title="Delete"><i class="fas fa-trash"></i></button>
        </td>
      </tr>`).join('');
  }
  renderPagination('quotePagination', data.length, quotePage, p => { quotePage = p; renderQuotes(); });
}

['quoteSearch','quoteStatusFilter'].forEach(id => {
  document.getElementById(id)?.addEventListener('input', () => { quotePage = 1; renderQuotes(); });
});
document.getElementById('quoteRefresh')?.addEventListener('click', async () => {
  _quotes = await getQuoteRequests(500);
  renderQuotes();
});

window.changeQuoteStatus = async function(sel) {
  const id = sel.dataset.id;
  const status = sel.value;
  try {
    await updateQuoteStatus(id, status);
    const idx = _quotes.findIndex(q => q.id === id);
    if (idx !== -1) _quotes[idx].status = status;
  } catch(err) { alert('Error updating status: ' + err.message); }
};

window.viewQuote = function(id) {
  const q = _quotes.find(x => x.id === id);
  if (!q) return;
  document.getElementById('quoteModalBody').innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px 24px;">
      ${detail('Name', q.name)} ${detail('Company', q.company)}
      ${detail('Email', q.email)} ${detail('Phone', q.phone)}
      ${detail('Origin', q.origin)} ${detail('Destination', q.destination)}
      ${detail('Mode', q.mode)} ${detail('Cargo Type', q.cargoType)}
      ${detail('Weight', q.weight ? q.weight + ' kg' : '—')} ${detail('Volume', q.volume ? q.volume + ' m³' : '—')}
      ${detail('Date', formatDate(q.createdAt))} ${detail('Status', q.status)}
      <div style="grid-column:1/-1">${detail('Message', q.message)}</div>
    </div>`;
  openModal('quoteModal');
};

function detail(label, val) {
  return `<div><div style="font-size:11px;color:#94a3b8;font-weight:600;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">${label}</div><div style="font-size:14px">${val || '—'}</div></div>`;
}

// ═══════════════════════════════════════
// MESSAGES
// ═══════════════════════════════════════
function getFilteredMessages() {
  const q = document.getElementById('msgSearch').value.toLowerCase();
  const readFilter = document.getElementById('msgReadFilter').value;
  return _contacts.filter(m =>
    (!q || [m.name, m.email, m.subject].some(v => v?.toLowerCase().includes(q))) &&
    (!readFilter || (readFilter === 'unread' ? !m.read : m.read))
  );
}

function renderMessages() {
  const data = getFilteredMessages();
  const start = (msgPage - 1) * PAGE_SIZE;
  const page  = data.slice(start, start + PAGE_SIZE);
  const tbody = document.getElementById('msgBody');
  if (page.length === 0) {
    tbody.innerHTML = '<tr class="empty-row"><td colspan="6">No messages found</td></tr>';
  } else {
    tbody.innerHTML = page.map(m => `
      <tr style="${!m.read ? 'font-weight:600' : ''}">
        <td>${formatDate(m.createdAt)}</td>
        <td>${m.name || '—'}</td>
        <td>${m.email || '—'}</td>
        <td>${m.subject || '—'}</td>
        <td><span class="status-badge ${m.read ? 'status-read' : 'status-unread'}">${m.read ? 'Read' : 'Unread'}</span></td>
        <td>
          <button class="btn-icon" onclick="viewMessage('${m.id}')" title="View"><i class="fas fa-eye"></i></button>
          <button class="btn-icon ${m.read ? '' : 'edit'}" onclick="toggleMessageRead('${m.id}')" title="${m.read ? 'Mark Unread' : 'Mark Read'}"><i class="fas ${m.read ? 'fa-envelope' : 'fa-envelope-open'}"></i></button>
          <button class="btn-icon del" onclick="confirmDelete('message','${m.id}')" title="Delete"><i class="fas fa-trash"></i></button>
        </td>
      </tr>`).join('');
  }
  renderPagination('msgPagination', data.length, msgPage, p => { msgPage = p; renderMessages(); });
  updateUnreadBadge();
}

['msgSearch','msgReadFilter'].forEach(id => {
  document.getElementById(id)?.addEventListener('input', () => { msgPage = 1; renderMessages(); });
});
document.getElementById('msgRefresh')?.addEventListener('click', async () => {
  _contacts = await getContactMessages(500);
  renderMessages();
});

window.viewMessage = async function(id) {
  const m = _contacts.find(x => x.id === id);
  if (!m) return;
  document.getElementById('msgModalBody').innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px 24px;">
      ${detail('Name', m.name)} ${detail('Email', m.email)}
      ${detail('Subject', m.subject)} ${detail('Date', formatDate(m.createdAt))}
      <div style="grid-column:1/-1">${detail('Message', m.message)}</div>
    </div>`;
  openModal('msgModal');
  if (!m.read) await toggleMessageRead(id);
};

window.toggleMessageRead = async function(id) {
  const idx = _contacts.findIndex(x => x.id === id);
  if (idx === -1) return;
  const newRead = !_contacts[idx].read;
  try {
    await updateContactStatus(id, newRead);
    _contacts[idx].read = newRead;
    renderMessages();
  } catch(err) { alert('Error: ' + err.message); }
};

// ═══════════════════════════════════════
// TRACKING LOOKUP
// ═══════════════════════════════════════
document.getElementById('adminTrackBtn')?.addEventListener('click', doAdminTrack);
document.getElementById('adminTrackInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') doAdminTrack(); });

async function doAdminTrack() {
  const trackId = document.getElementById('adminTrackInput').value.trim().toUpperCase();
  const resultDiv = document.getElementById('adminTrackResult');
  if (!trackId) { alert('Please enter a tracking ID.'); return; }
  resultDiv.style.display = 'block';
  resultDiv.innerHTML = '<p style="text-align:center;color:#94a3b8"><i class="fas fa-circle-notch fa-spin"></i> Looking up…</p>';
  try {
    const shipment = await getShipmentByTrackingId(trackId);
    if (!shipment) {
      resultDiv.innerHTML = `<p style="text-align:center;color:#f87171"><i class="fas fa-exclamation-circle"></i> Tracking ID <strong>${trackId}</strong> not found.</p>`;
      return;
    }
    const steps = ['Processing','In Transit','Customs Clearance','Out for Delivery','Delivered'];
    const stepIcons = ['fas fa-cog','fas fa-truck','fas fa-clipboard-check','fas fa-motorcycle','fas fa-check-circle'];
    const currentIdx = steps.indexOf(shipment.status);
    const stepsHtml = steps.map((step, i) => {
      const cls = i < currentIdx ? 'done' : i === currentIdx ? 'active' : '';
      return `<div class="track-step ${cls}">
        <div class="step-dot"><i class="${stepIcons[i]}"></i></div>
        <div class="step-label">${step}</div>
      </div>`;
    }).join('');
    resultDiv.innerHTML = `
      <h3 style="font-size:15px;font-weight:700;margin-bottom:16px"><i class="fas fa-box" style="color:#e8612d;margin-right:8px"></i>${shipment.trackingId}</h3>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;margin-bottom:20px">
        ${detail('Status','<span class="status-badge '+statusClass(shipment.status)+'">'+shipment.status+'</span>')}
        ${detail('From', shipment.origin)} ${detail('To', shipment.destination)}
        ${detail('Mode', shipment.mode)} ${detail('ETA', shipment.eta)}
        ${detail('Weight', shipment.weight ? shipment.weight+' kg' : '—')}
      </div>
      <div class="track-steps">${stepsHtml}</div>`;
  } catch(err) {
    resultDiv.innerHTML = `<p style="color:#f87171">Error: ${err.message}</p>`;
  }
}

// ═══════════════════════════════════════
// DELETE CONFIRMATION
// ═══════════════════════════════════════
window.confirmDelete = function(type, id) {
  const labels = { shipment: 'this shipment', quote: 'this quote request', message: 'this message' };
  document.getElementById('confirmMsg').textContent = `Are you sure you want to delete ${labels[type] || 'this item'}? This cannot be undone.`;
  pendingDeleteFn = async () => {
    try {
      if (type === 'shipment') { await deleteShipment(id); _shipments = _shipments.filter(s => s.id !== id); renderShipments(); renderDashboard(); }
      if (type === 'quote')    { await deleteQuoteRequest(id); _quotes = _quotes.filter(q => q.id !== id); renderQuotes(); }
      if (type === 'message')  { await deleteContactMessage(id); _contacts = _contacts.filter(m => m.id !== id); renderMessages(); }
      closeModal('confirmModal');
    } catch(err) { alert('Delete failed: ' + err.message); }
  };
  openModal('confirmModal');
};

document.getElementById('confirmDeleteBtn')?.addEventListener('click', () => {
  if (pendingDeleteFn) pendingDeleteFn();
});

// ═══════════════════════════════════════
// PAGINATION
// ═══════════════════════════════════════
function renderPagination(containerId, total, current, onPage) {
  const totalPages = Math.ceil(total / PAGE_SIZE);
  const container = document.getElementById(containerId);
  if (!container) return;
  if (totalPages <= 1) { container.innerHTML = ''; return; }
  let html = '';
  for (let i = 1; i <= totalPages; i++) {
    html += `<button class="page-btn ${i === current ? 'active' : ''}" onclick="(${onPage.toString()})(${i})">${i}</button>`;
  }
  container.innerHTML = html;
}

// ═══════════════════════════════════════
// SETTINGS — Change Password
// ═══════════════════════════════════════
document.getElementById('changePasswordBtn')?.addEventListener('click', () => {
  document.getElementById('changePasswordCard').style.display = 'block';
});

document.getElementById('savePwBtn')?.addEventListener('click', async () => {
  const np = document.getElementById('newPassword').value;
  const cp = document.getElementById('confirmPassword').value;
  const msg = document.getElementById('pwMsg');
  msg.style.display = 'none';
  if (np.length < 8) { showPwMsg('Password must be at least 8 characters.', 'error'); return; }
  if (np !== cp) { showPwMsg('Passwords do not match.', 'error'); return; }
  try {
    await updatePassword(np);
    showPwMsg('Password updated successfully!', 'success');
    document.getElementById('newPassword').value = '';
    document.getElementById('confirmPassword').value = '';
  } catch(err) {
    showPwMsg(err.message || 'Failed to update password.', 'error');
  }
});

function showPwMsg(text, type) {
  const msg = document.getElementById('pwMsg');
  msg.textContent = text;
  msg.className = 'settings-msg ' + type;
  msg.style.display = 'block';
}

// ═══════════════════════════════════════
// EMAILJS STATUS BADGE
// ═══════════════════════════════════════
function updateEmailJSBadge() {
  const badge = document.getElementById('emailjsStatusBadge');
  if (!badge) return;
  // Check if emailjs-config is loaded and enabled
  const enabled = typeof EMAILJS_CONFIG !== 'undefined' && EMAILJS_CONFIG.enabled
    && EMAILJS_CONFIG.publicKey !== 'YOUR_PUBLIC_KEY';
  if (enabled) {
    badge.style.background = 'rgba(34,197,94,0.1)';
    badge.style.color = '#4ade80';
    badge.style.borderColor = 'rgba(34,197,94,0.2)';
    badge.innerHTML = '<span style="width:7px;height:7px;border-radius:50%;background:#22c55e;display:inline-block;"></span> Active — email notifications enabled';
  } else {
    badge.style.background = 'rgba(239,68,68,0.1)';
    badge.style.color = '#f87171';
    badge.style.borderColor = 'rgba(239,68,68,0.2)';
    badge.innerHTML = '<span style="width:7px;height:7px;border-radius:50%;background:#f87171;display:inline-block;"></span> Not configured — notifications disabled';
  }
}

// ═══════════════════════════════════════
// INIT
// ═══════════════════════════════════════
async function init() {
  // Populate user info if already available
  if (window._currentUser) window.populateUserInfo(window._currentUser);
  // Load data
  await loadAllData();
  // Render initial tab
  renderDashboard();
  // Update EmailJS badge
  updateEmailJSBadge();
}

// Wait for auth overlay to be removed before initializing
// (auth guard in the HTML file handles this; we wait for DOM ready)
document.addEventListener('DOMContentLoaded', () => {
  // Small delay to allow auth guard to run first
  setTimeout(init, 200);
});
