/**
 * SwiftShip Global — EmailJS Configuration
 * ─────────────────────────────────────────
 * 1. Sign up free at https://www.emailjs.com
 * 2. Create an Email Service (Gmail, Outlook, etc.)
 * 3. Create two Email Templates (see template guide below)
 * 4. Fill in YOUR_* values below and set EMAILJS_ENABLED = true
 */

// ╔══════════════════════════════════════════╗
// ║  FILL IN YOUR EMAILJS CREDENTIALS HERE  ║
// ╚══════════════════════════════════════════╝
const EMAILJS_CONFIG = {
  enabled:        false,               // ← Set to true after adding your keys

  publicKey:      'YOUR_PUBLIC_KEY',   // EmailJS → Account → Public Key
  serviceId:      'YOUR_SERVICE_ID',   // EmailJS → Email Services → Service ID
  quoteTemplateId: 'YOUR_QUOTE_TEMPLATE_ID',   // Template for quote requests
  contactTemplateId: 'YOUR_CONTACT_TEMPLATE_ID', // Template for contact messages
  chatTemplateId: 'YOUR_CHAT_TEMPLATE_ID',  // Template for live chat transcripts

  // Address that receives all notifications
  adminEmail:     'info@swiftshipglobal.com',

  // "From" name shown in the email
  fromName:       'SwiftShip Global Website',
};

/*
 ═══════════════════════════════════════════════════
  EMAILJS TEMPLATE GUIDE
 ═══════════════════════════════════════════════════

 ── QUOTE REQUEST TEMPLATE (quoteTemplateId) ──────
 Subject:  New Quote Request — {{ref_number}}
 Body:
   Hello SwiftShip Team,

   A new quote request has been submitted.

   Reference:    {{ref_number}}
   Name:         {{from_name}}
   Company:      {{company}}
   Email:        {{from_email}}
   Phone:        {{phone}}
   Origin:       {{origin}}
   Destination:  {{destination}}
   Cargo Type:   {{cargo_type}}
   Mode:         {{shipment_mode}}
   Weight:       {{weight}} kg
   Volume:       {{volume}} m³
   Message:      {{message}}
   Submitted:    {{submitted_at}}

   Please respond within 24 hours.
   — SwiftShip Website

 ── CONTACT MESSAGE TEMPLATE (contactTemplateId) ──
 Subject:  New Contact Message — {{subject}}
 Body:
   Hello SwiftShip Team,

   A new contact message has been received.

   Ticket:    {{ticket_number}}
   Name:      {{from_name}}
   Email:     {{from_email}}
   Phone:     {{phone}}
   Subject:   {{subject}}
   Message:   {{message}}
   Received:  {{submitted_at}}

   — SwiftShip Website

 ── CHAT TRANSCRIPT TEMPLATE (chatTemplateId) ──────
 Subject:  New Live Chat — {{visitor_name}}
 Body:
   A visitor started a live chat session.

   Visitor:   {{visitor_name}}
   Email:     {{visitor_email}}
   Session:   {{session_id}}
   Message:   {{first_message}}
   Time:      {{submitted_at}}

   — SwiftShip Live Chat

 ═══════════════════════════════════════════════════
*/

// ── Init EmailJS SDK ─────────────────────────────
function initEmailJS() {
  if (!EMAILJS_CONFIG.enabled) {
    console.info('[EmailJS] Disabled — set EMAILJS_CONFIG.enabled = true to activate.');
    return false;
  }
  if (typeof emailjs === 'undefined') {
    console.warn('[EmailJS] SDK not loaded. Make sure the CDN script is in your HTML.');
    return false;
  }
  try {
    emailjs.init({ publicKey: EMAILJS_CONFIG.publicKey });
    console.log('[EmailJS] Initialised ✓');
    return true;
  } catch(e) {
    console.error('[EmailJS] Init error:', e);
    return false;
  }
}

// ── Send Quote Notification ──────────────────────
async function emailQuoteNotification(data, refNumber) {
  if (!EMAILJS_CONFIG.enabled) return { skipped: true };
  if (typeof emailjs === 'undefined') return { skipped: true };

  const templateParams = {
    to_email:      EMAILJS_CONFIG.adminEmail,
    from_name:     data.name         || '',
    company:       data.company      || '—',
    from_email:    data.email        || '',
    phone:         data.phone        || '—',
    origin:        data.origin       || '',
    destination:   data.destination  || '',
    cargo_type:    data.cargoType    || '',
    shipment_mode: data.mode         || '',
    weight:        data.weight       || '—',
    volume:        data.volume       || '—',
    message:       data.message      || '—',
    ref_number:    refNumber,
    submitted_at:  new Date().toLocaleString(),
  };

  try {
    const response = await emailjs.send(
      EMAILJS_CONFIG.serviceId,
      EMAILJS_CONFIG.quoteTemplateId,
      templateParams
    );
    console.log('[EmailJS] Quote email sent:', response.status);
    return response;
  } catch(err) {
    console.error('[EmailJS] Quote email failed:', err);
    throw err;
  }
}

// ── Send Contact Notification ─────────────────────
async function emailContactNotification(data, ticketNumber) {
  if (!EMAILJS_CONFIG.enabled) return { skipped: true };
  if (typeof emailjs === 'undefined') return { skipped: true };

  const templateParams = {
    to_email:      EMAILJS_CONFIG.adminEmail,
    from_name:     data.name    || '',
    from_email:    data.email   || '',
    phone:         data.phone   || '—',
    subject:       data.subject || '',
    message:       data.message || '',
    ticket_number: ticketNumber,
    submitted_at:  new Date().toLocaleString(),
  };

  try {
    const response = await emailjs.send(
      EMAILJS_CONFIG.serviceId,
      EMAILJS_CONFIG.contactTemplateId,
      templateParams
    );
    console.log('[EmailJS] Contact email sent:', response.status);
    return response;
  } catch(err) {
    console.error('[EmailJS] Contact email failed:', err);
    throw err;
  }
}

// ── Send Chat Transcript Notification ────────────
async function emailChatNotification(visitorName, visitorEmail, sessionId, firstMessage) {
  if (!EMAILJS_CONFIG.enabled) return { skipped: true };
  if (typeof emailjs === 'undefined') return { skipped: true };

  const templateParams = {
    to_email:      EMAILJS_CONFIG.adminEmail,
    visitor_name:  visitorName   || 'Visitor',
    visitor_email: visitorEmail  || '—',
    session_id:    sessionId     || '',
    first_message: firstMessage  || '',
    submitted_at:  new Date().toLocaleString(),
  };

  try {
    const response = await emailjs.send(
      EMAILJS_CONFIG.serviceId,
      EMAILJS_CONFIG.chatTemplateId,
      templateParams
    );
    console.log('[EmailJS] Chat notification sent:', response.status);
    return response;
  } catch(err) {
    console.error('[EmailJS] Chat notification failed:', err);
    // Non-critical — don't throw, just warn
    return { error: err.message };
  }
}

// ── Auto-init on load ────────────────────────────
document.addEventListener('DOMContentLoaded', initEmailJS);
