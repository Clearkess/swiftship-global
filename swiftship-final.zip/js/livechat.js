/**
 * SwiftShip Global — Live Chat Widget
 * Real-time messaging via Firestore with localStorage fallback
 */

'use strict';

// ── Config ──────────────────────────────────────────────────
const CHAT_CONFIG = {
  agentName:   'SwiftShip Support',
  agentAvatar: 'SS',
  greetDelay:  1200,   // ms before greeting appears
  typingDelay: 1400,   // ms to show "typing…" before bot reply
  soundEnabled: true,
  autoReplies: [
    { match: /track|tracking|shipment|where.*package|where.*order/i,
      reply: '📦 To track your shipment, enter your tracking ID in the tracking section above — or share it here and I\'ll look it up for you!' },
    { match: /quote|price|cost|rate|how much/i,
      reply: '💰 I\'d love to get you a quote! Please fill out the Request a Quote form on this page, or tell me your origin, destination, and cargo type here.' },
    { match: /sea|ocean|fcl|lcl/i,
      reply: '🚢 Our sea freight service covers FCL & LCL to any major port worldwide. Transit times vary by route — typical trans-Atlantic is 10–14 days.' },
    { match: /air|express|urgent|fast|quick/i,
      reply: '✈️ Need it fast? Our air freight express service delivers in 1–3 business days to most global destinations. Shall I connect you with an agent for a quote?' },
    { match: /road|truck|trucking|ground/i,
      reply: '🚛 Our road freight covers FTL and LTL across North America and Europe with GPS-tracked vehicles and real-time updates.' },
    { match: /custom|import|export|duty|clearance/i,
      reply: '📋 Our customs brokerage team handles clearance in 180+ countries. We manage all documentation, duties, and compliance on your behalf.' },
    { match: /warehouse|storage|inventory/i,
      reply: '🏭 We offer flexible warehousing solutions — short and long term — with full inventory management and distribution services.' },
    { match: /hello|hi|hey|good morning|good afternoon|good evening|howdy/i,
      reply: 'Hello! 👋 Welcome to SwiftShip Global. How can I help you today? I can assist with tracking, quotes, services, and more.' },
    { match: /thank|thanks|thank you/i,
      reply: 'You\'re welcome! 😊 Is there anything else I can help you with?' },
    { match: /bye|goodbye|see you|that.*all/i,
      reply: 'Thanks for reaching out to SwiftShip Global! 🚀 Safe travels and happy shipping. Our team is here 24/7 if you need us.' },
    { match: /human|agent|person|representative|speak to someone/i,
      reply: '👤 I\'ll connect you with a live agent right away! In the meantime, you can also reach us at info@swiftshipglobal.com or call +1 (800) 123-4567.' },
    { match: /phone|call|number|contact/i,
      reply: '📞 You can reach us at +1 (800) 123-4567, Mon–Fri 8am–8pm, Sat 9am–4pm. Or email us at info@swiftshipglobal.com.' },
  ],
  defaultReply: '🤔 Thanks for your message! Let me connect you with our support team. You can also reach us at info@swiftshipglobal.com or call +1 (800) 123-4567 for immediate assistance.'
};

// ── State ────────────────────────────────────────────────────
let _sessionId    = null;
let _chatOpen     = false;
let _unreadCount  = 0;
let _messages     = [];
let _firestoreUnsub = null;
let _userName     = '';
let _userEmail    = '';
let _nameCollected = false;
let _audioCtx     = null;

// ── Session ID ───────────────────────────────────────────────
function getSessionId() {
  if (_sessionId) return _sessionId;
  _sessionId = localStorage.getItem('swiftship_chat_session');
  if (!_sessionId) {
    _sessionId = 'chat_' + Date.now() + '_' + Math.random().toString(36).substr(2, 8);
    localStorage.setItem('swiftship_chat_session', _sessionId);
  }
  return _sessionId;
}

// ── Notification sound ───────────────────────────────────────
function playNotificationSound() {
  if (!CHAT_CONFIG.soundEnabled) return;
  try {
    if (!_audioCtx) _audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc  = _audioCtx.createOscillator();
    const gain = _audioCtx.createGain();
    osc.connect(gain);
    gain.connect(_audioCtx.destination);
    osc.frequency.setValueAtTime(880, _audioCtx.currentTime);
    osc.frequency.setValueAtTime(1100, _audioCtx.currentTime + 0.1);
    gain.gain.setValueAtTime(0.15, _audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, _audioCtx.currentTime + 0.35);
    osc.start(_audioCtx.currentTime);
    osc.stop(_audioCtx.currentTime + 0.35);
  } catch(e) {}
}

// ── Firestore helpers ────────────────────────────────────────
async function saveChatMessage(msg) {
  if (typeof FIREBASE_ENABLED !== 'undefined' && FIREBASE_ENABLED && typeof firebase !== 'undefined') {
    try {
      const db = firebase.firestore();
      await db.collection('live_chats').doc(getSessionId())
        .collection('messages').add({
          ...msg,
          sessionId: getSessionId(),
          userName:  _userName || 'Visitor',
          userEmail: _userEmail || '',
          createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
      // Update session metadata
      await db.collection('live_chats').doc(getSessionId()).set({
        sessionId:  getSessionId(),
        userName:   _userName || 'Visitor',
        userEmail:  _userEmail || '',
        lastMessage: msg.text,
        lastAt:     firebase.firestore.FieldValue.serverTimestamp(),
        status:     'active'
      }, { merge: true });
    } catch(e) {
      console.warn('[Chat] Firestore save failed, using localStorage:', e.message);
      saveToLocalStorage(msg);
    }
  } else {
    saveToLocalStorage(msg);
  }
}

function saveToLocalStorage(msg) {
  const key  = 'swiftship_chat_msgs_' + getSessionId();
  const msgs = JSON.parse(localStorage.getItem(key) || '[]');
  msgs.push({ ...msg, id: Date.now().toString() });
  localStorage.setItem(key, JSON.stringify(msgs));
}

function loadFromLocalStorage() {
  const key = 'swiftship_chat_msgs_' + getSessionId();
  return JSON.parse(localStorage.getItem(key) || '[]');
}

// ── Auto-reply logic ─────────────────────────────────────────
function getAutoReply(text) {
  for (const rule of CHAT_CONFIG.autoReplies) {
    if (rule.match.test(text)) return rule.reply;
  }
  return CHAT_CONFIG.defaultReply;
}

// ── DOM helpers ──────────────────────────────────────────────
function el(id) { return document.getElementById(id); }

function formatTime(date) {
  return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function appendMessage(msg, animate = true) {
  const body = el('chatBody');
  if (!body) return;

  const div = document.createElement('div');
  div.className = 'chat-msg ' + (msg.sender === 'user' ? 'chat-msg-user' : 'chat-msg-agent') + (animate ? ' chat-msg-new' : '');
  div.innerHTML = msg.sender === 'agent'
    ? `<div class="chat-avatar">${CHAT_CONFIG.agentAvatar}</div>
       <div class="chat-bubble-wrap">
         <div class="chat-bubble">${msg.text}</div>
         <div class="chat-time">${CHAT_CONFIG.agentName} · ${formatTime(msg.ts || Date.now())}</div>
       </div>`
    : `<div class="chat-bubble-wrap">
         <div class="chat-bubble">${escapeHtml(msg.text)}</div>
         <div class="chat-time">${formatTime(msg.ts || Date.now())}</div>
       </div>`;

  body.appendChild(div);
  body.scrollTop = body.scrollHeight;

  // Remove animation class
  setTimeout(() => div.classList.remove('chat-msg-new'), 400);
}

function showTyping() {
  const body = el('chatBody');
  if (!body || el('chatTyping')) return;
  const div = document.createElement('div');
  div.id = 'chatTyping';
  div.className = 'chat-msg chat-msg-agent';
  div.innerHTML = `<div class="chat-avatar">${CHAT_CONFIG.agentAvatar}</div>
    <div class="chat-bubble-wrap"><div class="chat-bubble typing-bubble"><span></span><span></span><span></span></div></div>`;
  body.appendChild(div);
  body.scrollTop = body.scrollHeight;
}

function hideTyping() {
  const t = el('chatTyping');
  if (t) t.remove();
}

function setUnread(count) {
  _unreadCount = count;
  const badge = el('chatBadge');
  if (badge) {
    badge.textContent = count;
    badge.style.display = count > 0 ? 'flex' : 'none';
  }
}

function escapeHtml(text) {
  return text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── Send message ─────────────────────────────────────────────
async function sendUserMessage(text) {
  text = text.trim();
  if (!text) return;

  const msg = { sender: 'user', text, ts: Date.now() };
  _messages.push(msg);
  appendMessage(msg);
  await saveChatMessage(msg);

  el('chatInput').value = '';
  el('chatInput').style.height = 'auto';
  el('chatSendBtn').disabled = true;

  // Show typing indicator then reply
  showTyping();
  setTimeout(async () => {
    hideTyping();
    const replyText = getAutoReply(text);
    const replyMsg  = { sender: 'agent', text: replyText, ts: Date.now() };
    _messages.push(replyMsg);
    appendMessage(replyMsg);
    await saveChatMessage(replyMsg);
    if (!_chatOpen) {
      setUnread(_unreadCount + 1);
      playNotificationSound();
    }
  }, CHAT_CONFIG.typingDelay);
}

// ── Name collection flow ─────────────────────────────────────
function showNameForm() {
  const body = el('chatBody');
  if (!body) return;
  const div = document.createElement('div');
  div.id = 'chatNameForm';
  div.className = 'chat-name-form';
  div.innerHTML = `
    <p>Before we start, what's your name?</p>
    <div class="chat-name-inputs">
      <input type="text" id="chatNameInput" placeholder="Your name" maxlength="50" />
      <input type="email" id="chatEmailInput" placeholder="Email (optional)" />
      <button id="chatNameSubmit" class="chat-start-btn">Start Chat <i class="fas fa-arrow-right"></i></button>
    </div>`;
  body.appendChild(div);

  el('chatNameInput').focus();
  el('chatNameSubmit').addEventListener('click', submitName);
  el('chatNameInput').addEventListener('keydown', e => { if (e.key === 'Enter') submitName(); });
}

function submitName() {
  const nameInput  = el('chatNameInput');
  const emailInput = el('chatEmailInput');
  if (!nameInput.value.trim()) { nameInput.style.borderColor = '#ef4444'; return; }
  _userName  = nameInput.value.trim();
  _userEmail = emailInput?.value.trim() || '';
  _nameCollected = true;
  const form = el('chatNameForm');
  if (form) form.remove();
  localStorage.setItem('swiftship_chat_name',  _userName);
  localStorage.setItem('swiftship_chat_email', _userEmail);
  // Send greeting
  sendAgentGreeting();
  // Enable input
  el('chatInput').disabled = false;
  el('chatInput').placeholder = 'Type a message…';
  el('chatInput').focus();
}

function sendAgentGreeting() {
  setTimeout(() => {
    showTyping();
    setTimeout(() => {
      hideTyping();
      const greeting = `Hi ${_userName}! 👋 I'm your SwiftShip support agent. How can I help you today? I can assist with shipment tracking, freight quotes, customs info, and more!`;
      const msg = { sender: 'agent', text: greeting, ts: Date.now() };
      _messages.push(msg);
      appendMessage(msg);
      saveChatMessage(msg);
      // Notify admin via EmailJS when a new chat session starts
      if (typeof emailChatNotification === 'function') {
        emailChatNotification(_userName, _userEmail, getSessionId(), greeting).catch(() => {});
      }
    }, CHAT_CONFIG.typingDelay);
  }, CHAT_CONFIG.greetDelay);
}

// ── Open / Close ──────────────────────────────────────────────
function openChat() {
  _chatOpen = true;
  setUnread(0);
  const win = el('chatWindow');
  win.classList.add('open');
  el('chatToggleBtn').setAttribute('aria-expanded', 'true');

  // Load saved name
  if (!_nameCollected) {
    const savedName  = localStorage.getItem('swiftship_chat_name');
    const savedEmail = localStorage.getItem('swiftship_chat_email');
    if (savedName) {
      _userName       = savedName;
      _userEmail      = savedEmail || '';
      _nameCollected  = true;
      el('chatInput').disabled = false;
      el('chatInput').placeholder = 'Type a message…';
      // Restore previous messages
      const prev = loadFromLocalStorage();
      if (prev.length > 0) {
        prev.forEach(m => appendMessage(m, false));
      } else {
        sendAgentGreeting();
      }
    } else {
      el('chatInput').disabled = true;
      el('chatInput').placeholder = 'Please enter your name first…';
      showNameForm();
    }
  }

  setTimeout(() => el('chatInput').focus(), 300);
}

function closeChat() {
  _chatOpen = false;
  el('chatWindow').classList.remove('open');
  el('chatToggleBtn').setAttribute('aria-expanded', 'false');
}

// ── Init widget ───────────────────────────────────────────────
function initLiveChat() {
  const toggleBtn = el('chatToggleBtn');
  const closeBtn  = el('chatCloseBtn');
  const sendBtn   = el('chatSendBtn');
  const input     = el('chatInput');

  if (!toggleBtn) return;

  // Open/close
  toggleBtn.addEventListener('click', () => _chatOpen ? closeChat() : openChat());
  closeBtn?.addEventListener('click', closeChat);

  // Send on button click
  sendBtn?.addEventListener('click', () => sendUserMessage(input.value));

  // Send on Enter (Shift+Enter = new line)
  input?.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendUserMessage(input.value);
    }
  });

  // Auto-grow textarea
  input?.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 120) + 'px';
    sendBtn.disabled = !input.value.trim();
  });

  // Show badge after delay if not opened yet (no sound — user hasn't interacted yet)
  setTimeout(() => {
    if (!_chatOpen && !localStorage.getItem('swiftship_chat_name')) {
      setUnread(1);
    }
  }, 6000);

  // Pulse animation on FAB after 3s
  setTimeout(() => {
    toggleBtn.classList.add('pulse');
    setTimeout(() => toggleBtn.classList.remove('pulse'), 3000);
  }, 3000);

  // Pre-warm AudioContext on first user interaction to avoid autoplay warning
  const warmAudio = () => {
    try {
      if (!_audioCtx) _audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      if (_audioCtx.state === 'suspended') _audioCtx.resume();
    } catch(e) {}
    document.removeEventListener('click', warmAudio);
  };
  document.addEventListener('click', warmAudio);
}

document.addEventListener('DOMContentLoaded', initLiveChat);
